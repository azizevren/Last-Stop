import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'Last Stop | Street Food in Olten',description:'Dein nächster Halt für Pizza, Burger und Street Food. Aarauerstrasse 81, Olten.',robots:{index:false,follow:false}};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="de-CH"><body>{children}</body></html>}
