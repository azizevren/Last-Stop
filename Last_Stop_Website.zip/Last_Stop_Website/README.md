# Last Stop Olten — Website

Last Stop Street Food, Aarauerstrasse 81, 4600 Olten.

Bu paket ilk onaylanan site tasariminin kaynak kodlarini ve gorsellerini icerir.
Menu fiyatlari onceki taslaklara dayanir; guncel menuyle kontrol edilmelidir.
Gercek siparis gonderimi veya odeme sistemi yoktur.

## GitHub'a yukleme

1. ZIP'i Dosyalar uygulamasinda acin.
2. Last-Stop deposunda Add file > Upload files bolumunu acin.
3. ZIP'in kendisini degil, Last_Stop_Website klasorunun ICINDEKI dosya ve klasorleri yukleyin.
4. Commit changes dugmesine basin.

GitHub'a kaynak kod yuklemek siteyi otomatik yayinlamaz.
Bu proje Vinext/React ve Cloudflare Worker yapisindadir; GitHub Pages icin ayrica statik surum hazirlanmalidir.
Telefon dosya secicisi klasor veya gizli dosyalari secmeye izin vermezse bilgisayardan yukleyin.

## Duzenlenecek dosyalar

- app/page.tsx: menu, fiyatlar, metinler
- app/globals.css: tasarim
- public/images/: yemek gorselleri

## Yerel gelistirme

Node.js 22.13 veya ustu gerekir.

```sh
npm ci
npm run dev
```

Derleme: `npm run build`.

Yemek fotograflari temsilidir. Calisma saatleri ve siparis baglantilari henuz tamamlanmamistir.
